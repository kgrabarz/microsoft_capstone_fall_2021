import os

filenames = next(os.walk("."), (None, None, []))[2]  # [] if no file

# Renaming the file
for filename in filenames:
	os.rename(filename, filename.replace("German","COMPAS"))